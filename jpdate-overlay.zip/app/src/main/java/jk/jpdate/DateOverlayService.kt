package jk.jpdate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max

/**
 * 画面上に日本語の年月日を常時表示するフォアグラウンドサービス。
 * ドラッグで任意の位置へ移動でき、位置は保存される。長押しで設定画面を開く。
 */
class DateOverlayService : Service() {

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private var label: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var receiverRegistered = false

    private val tick = object : Runnable {
        override fun run() {
            refreshText()
            handler.postDelayed(this, nextDelay())
        }
    }

    /** 秒表示なら1秒ごと、そうでなければ分の境目に合わせて更新 */
    private fun nextDelay(): Long {
        val now = System.currentTimeMillis()
        return if (prefs.timeMode == 2) {
            1000L - (now % 1000L) + 5L
        } else {
            60_000L - (now % 60_000L) + 50L
        }
    }

    /** 時刻・タイムゾーン変更や画面ON/OFFに追従 */
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> handler.removeCallbacks(tick)
                else -> restartTick()
            }
        }
    }

    private fun restartTick() {
        handler.removeCallbacks(tick)
        if (label != null) handler.post(tick)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true

        if (Settings.canDrawOverlays(this)) {
            attachOverlay()
            handler.post(tick)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.enabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                applyAppearance()
                restartTick()
            }
            ACTION_RESET_POS -> {
                prefs.resetPosition()
                placeDefault()
            }
            else -> {
                prefs.enabled = true
                if (label == null && Settings.canDrawOverlays(this)) {
                    attachOverlay()
                    handler.post(tick)
                } else {
                    applyAppearance()
                    restartTick()
                }
            }
        }
        // プリセット位置の指定
        intent?.let {
            if (it.hasExtra(EXTRA_PRESET)) movePreset(it.getIntExtra(EXTRA_PRESET, PRESET_LEFT))
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 回転・ダークモード切替で画面外に出ないよう補正し、見た目も更新
        handler.post {
            applyAppearance()
            label?.post { clampPosition(save = true) }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        detachOverlay()
        super.onDestroy()
    }

    private fun attachOverlay() {
        if (label != null) return

        val tv = TextView(this).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            isClickable = true
            isFocusable = false
        }
        label = tv

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val dm = resources.displayMetrics
            x = if (prefs.x >= 0) prefs.x else (dm.widthPixels * 0.05f).toInt()
            y = if (prefs.y >= 0) prefs.y else (dm.heightPixels * 0.02f).toInt()
        }
        lp = params

        setupTouch(tv, params)
        applyAppearance()

        try {
            wm.addView(tv, params)
            tv.post { clampPosition(save = false) }
        } catch (_: Exception) {
            label = null
            lp = null
        }
    }

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        // ロック時はタッチを素通りさせ、下のアプリの操作を邪魔しない
        if (prefs.lockPos) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun detachOverlay() {
        label?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        label = null
        lp = null
    }

    private fun setupTouch(view: View, params: WindowManager.LayoutParams) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var downTime = 0L
        var moved = false

        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = params.x
                    startY = params.y
                    downTime = SystemClock.uptimeMillis()
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downX).toInt()
                    val dy = (ev.rawY - downY).toInt()
                    if (!moved && (abs(dx) > 8 || abs(dy) > 8)) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        clampPosition(save = false)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.x = params.x
                        prefs.y = params.y
                    } else if (SystemClock.uptimeMillis() - downTime >= 500L) {
                        // 長押しで設定画面を開く
                        openSettings()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        prefs.x = params.x
                        prefs.y = params.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun openSettings() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Exception) {}
    }

    /** 画面外に出ないよう座標を補正して反映 */
    private fun clampPosition(save: Boolean) {
        val tv = label ?: return
        val p = lp ?: return
        val dm = resources.displayMetrics
        val maxX = max(0, dm.widthPixels - tv.width)
        val maxY = max(0, dm.heightPixels - tv.height)
        p.x = p.x.coerceIn(0, maxX)
        p.y = p.y.coerceIn(0, maxY)
        try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
        if (save) {
            prefs.x = p.x
            prefs.y = p.y
        }
    }

    private fun placeDefault() {
        val p = lp ?: return
        val dm = resources.displayMetrics
        p.x = (dm.widthPixels * 0.05f).toInt()
        p.y = (dm.heightPixels * 0.02f).toInt()
        clampPosition(save = false)
    }

    private fun movePreset(preset: Int) {
        val tv = label ?: return
        val p = lp ?: return
        val dm = resources.displayMetrics
        val margin = dp(8)
        p.x = when (preset) {
            PRESET_CENTER -> (dm.widthPixels - tv.width) / 2
            PRESET_RIGHT -> dm.widthPixels - tv.width - margin
            else -> margin
        }
        p.y = margin
        clampPosition(save = true)
    }

    private fun applyAppearance() {
        val tv = label ?: return
        val p = lp
        OverlayStyle.apply(this, tv, prefs)
        if (p != null) {
            p.flags = baseFlags()
            try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
        }
        // 文字数が変わると幅も変わるので補正
        tv.post { clampPosition(save = false) }
    }

    private fun refreshText() {
        val tv = label ?: return
        val pal = OverlayStyle.palette(this, prefs)
        val text = DateFormatJp.build(prefs, pal.darkBg)
        if (tv.text?.toString() != text.toString()) {
            tv.text = text
            tv.post { clampPosition(save = false) }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val chId = "jpdate_overlay"
        if (nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    chId,
                    getString(R.string.notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                ).apply { setShowBadge(false) }
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, DateOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, chId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(open)
            .addAction(0, "停止", stop)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        const val NOTIF_ID = 42
        const val ACTION_STOP = "jk.jpdate.STOP"
        const val ACTION_REFRESH = "jk.jpdate.REFRESH"
        const val ACTION_RESET_POS = "jk.jpdate.RESET_POS"
        const val EXTRA_PRESET = "preset"
        const val PRESET_LEFT = 0
        const val PRESET_CENTER = 1
        const val PRESET_RIGHT = 2

        fun start(ctx: Context) {
            val i = Intent(ctx, DateOverlayService::class.java)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_STOP)
            ctx.startService(i)
        }

        fun refresh(ctx: Context) {
            if (!Prefs(ctx).enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_REFRESH)
            ctx.startService(i)
        }

        fun resetPosition(ctx: Context) {
            val p = Prefs(ctx)
            p.resetPosition()
            if (!p.enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_RESET_POS)
            ctx.startService(i)
        }

        fun movePreset(ctx: Context, preset: Int) {
            if (!Prefs(ctx).enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).putExtra(EXTRA_PRESET, preset)
            ctx.startService(i)
        }
    }
}
