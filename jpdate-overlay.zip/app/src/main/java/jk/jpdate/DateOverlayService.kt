package jk.jpdate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.PowerManager
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max

/**
 * 画面上に日本語の年月日を常時表示するフォアグラウンドサービス。
 * ドラッグで任意の位置へ移動でき、位置は保存される。長押しで設定画面を開く。
 */
class DateOverlayService : Service() {

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private var label: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var receiverRegistered = false
    private var screenOn = true

    // ミニカレンダー
    private var cal: MiniCalendarView? = null
    private var calLp: WindowManager.LayoutParams? = null
    private val calDismiss = Runnable { hideCalendar() }

    // アプリ別ルール（前面アプリの検出）
    private var hiddenByApp = false
    private var lastPkg: String? = null
    private var lastQuery = 0L
    private val fgPoll = object : Runnable {
        override fun run() {
            pollForeground()
            evaluateAppRule()
            handler.postDelayed(this, 1500L)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshText()
            handler.postDelayed(this, nextDelay())
        }
    }

    /** 秒表示なら1秒ごと、そうでなければ分の境目に合わせて更新 */
    private fun nextDelay(): Long {
        val now = System.currentTimeMillis()
        return if (prefs.timeMode == 2) {
            1000L - (now % 1000L) + 5L
        } else {
            60_000L - (now % 60_000L) + 50L
        }
    }

    /** 時刻・タイムゾーン変更や画面ON/OFFに追従 */
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    handler.removeCallbacks(tick)
                    handler.removeCallbacks(fgPoll)
                    hideCalendar()
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    restartTick()
                    updateFgPolling()
                }
                else -> restartTick()
            }
        }
    }

    private fun restartTick() {
        handler.removeCallbacks(tick)
        if (label != null) handler.post(tick)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        screenOn = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true

        if (Settings.canDrawOverlays(this)) {
            attachOverlay()
            handler.post(tick)
            updateFgPolling()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.enabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                hideCalendar()
                applyAppearance()
                restartTick()
                updateFgPolling()
            }
            ACTION_RESET_POS -> {
                prefs.resetPosition()
                placeDefault()
            }
            else -> {
                prefs.enabled = true
                if (label == null && Settings.canDrawOverlays(this)) {
                    attachOverlay()
                    handler.post(tick)
                } else {
                    applyAppearance()
                    restartTick()
                }
                updateFgPolling()
            }
        }
        // プリセット位置の指定
        intent?.let {
            if (it.hasExtra(EXTRA_PRESET)) movePreset(it.getIntExtra(EXTRA_PRESET, PRESET_LEFT))
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 回転・ダークモード切替で画面外に出ないよう補正し、見た目も更新
        // 縦横で保存位置が違うので、向きに合った位置を読み直してから補正する
        handler.post {
            hideCalendar()
            loadPosition()
            applyAppearance()
            label?.post { clampPosition(save = false) }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(fgPoll)
        hideCalendar()
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        detachOverlay()
        super.onDestroy()
    }

    private fun attachOverlay() {
        if (label != null) return

        val tv = TextView(this).apply {
            setPadding(dp(12), dp(6), dp(12), dp(6))
            isClickable = true
            isFocusable = false
        }
        label = tv

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val dm = resources.displayMetrics
            x = if (prefs.x >= 0) prefs.x else (dm.widthPixels * 0.05f).toInt()
            y = if (prefs.y >= 0) prefs.y else (dm.heightPixels * 0.02f).toInt()
        }
        lp = params

        setupTouch(tv, params)
        applyAppearance()

        try {
            wm.addView(tv, params)
            tv.post { clampPosition(save = false) }
        } catch (_: Exception) {
            label = null
            lp = null
        }
    }

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        // ロック時はタッチを素通りさせ、下のアプリの操作を邪魔しない
        if (prefs.lockPos) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun detachOverlay() {
        hideCalendar()
        label?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        label = null
        lp = null
    }

    private fun setupTouch(view: View, params: WindowManager.LayoutParams) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var downTime = 0L
        var moved = false

        view.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = params.x
                    startY = params.y
                    downTime = SystemClock.uptimeMillis()
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downX).toInt()
                    val dy = (ev.rawY - downY).toInt()
                    if (!moved && (abs(dx) > 8 || abs(dy) > 8)) {
                        moved = true
                        hideCalendar()
                    }
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        clampPosition(save = false)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.x = params.x
                        prefs.y = params.y
                    } else if (SystemClock.uptimeMillis() - downTime >= 500L) {
                        // 長押しで設定画面を開く
                        openSettings()
                    } else if (prefs.tapCalendar) {
                        // 短いタップでミニカレンダー
                        toggleCalendar()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        prefs.x = params.x
                        prefs.y = params.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ---------- ミニカレンダー ----------

    private fun toggleCalendar() {
        if (cal != null) hideCalendar() else showCalendar()
    }

    private fun showCalendar() {
        val anchor = label ?: return
        if (anchor.visibility != View.VISIBLE) return
        val v = MiniCalendarView(
            this, prefs,
            onInteract = { scheduleCalDismiss() },
            onResize = { repositionCalendar() },
            onClose = { hideCalendar() }
        )
        v.show(java.time.YearMonth.now())
        v.alpha = OverlayStyle.dimFactor(prefs)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        placeCalendar(v, params)
        try {
            wm.addView(v, params)
            cal = v
            calLp = params
            scheduleCalDismiss()
        } catch (_: Exception) {}
    }

    /** 日付ラベルの下（入らなければ上）に置く */
    private fun placeCalendar(v: View, p: WindowManager.LayoutParams) {
        val anchor = label ?: return
        val ap = lp ?: return
        val dm = resources.displayMetrics
        v.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(dm.heightPixels, View.MeasureSpec.AT_MOST)
        )
        val w = v.measuredWidth
        val h = v.measuredHeight
        p.x = ap.x.coerceIn(0, max(0, dm.widthPixels - w))
        val below = ap.y + anchor.height + dp(6)
        p.y = if (below + h <= dm.heightPixels) below else max(0, ap.y - h - dp(6))
    }

    private fun repositionCalendar() {
        val v = cal ?: return
        val p = calLp ?: return
        placeCalendar(v, p)
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun scheduleCalDismiss() {
        handler.removeCallbacks(calDismiss)
        handler.postDelayed(calDismiss, 7000L)
    }

    private fun hideCalendar() {
        handler.removeCallbacks(calDismiss)
        cal?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cal = null
        calLp = null
    }

    // ---------- アプリ別ルール ----------

    /** 条件がそろっているときだけ前面アプリの監視を動かす */
    private fun updateFgPolling() {
        handler.removeCallbacks(fgPoll)
        val active = prefs.appRuleEnabled &&
            prefs.appRuleApps.isNotEmpty() &&
            screenOn &&
            label != null &&
            AppRule.hasUsageAccess(this)
        if (active) {
            handler.post(fgPoll)
        } else if (hiddenByApp) {
            hiddenByApp = false
            updateVisibility()
        }
    }

    /** 前回以降のイベントから、いま前面のアプリを更新 */
    @Suppress("DEPRECATION")
    private fun pollForeground() {
        try {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val from = if (lastQuery == 0L) now - 6 * 3600_000L else lastQuery - 1000L
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastPkg = e.packageName
            }
            lastQuery = now
        } catch (_: Exception) {}
    }

    private fun evaluateAppRule() {
        val pkg = lastPkg
        val inList = pkg != null && pkg in prefs.appRuleApps
        var hide = if (prefs.appRuleMode == 0) inList else !inList
        if (pkg == packageName) hide = false // 設定画面を開いている間は隠さない
        if (hide != hiddenByApp) {
            hiddenByApp = hide
            updateVisibility()
        }
    }

    private fun openSettings() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (_: Exception) {}
    }

    /** 画面外に出ないよう座標を補正して反映 */
    private fun clampPosition(save: Boolean) {
        val tv = label ?: return
        val p = lp ?: return
        if (tv.visibility == View.GONE) return
        val dm = resources.displayMetrics
        val maxX = max(0, dm.widthPixels - tv.width)
        val maxY = max(0, dm.heightPixels - tv.height)
        p.x = p.x.coerceIn(0, maxX)
        p.y = p.y.coerceIn(0, maxY)
        try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
        if (save) {
            prefs.x = p.x
            prefs.y = p.y
        }
    }

    /** いまの向きに保存された位置を反映（未保存なら初期位置） */
    private fun loadPosition() {
        val p = lp ?: return
        val dm = resources.displayMetrics
        p.x = if (prefs.x >= 0) prefs.x else (dm.widthPixels * 0.05f).toInt()
        p.y = if (prefs.y >= 0) prefs.y else (dm.heightPixels * 0.02f).toInt()
    }

    /** 「横向きのとき非表示」が有効で、いま横向きなら隠す */
    private fun shouldHide(): Boolean =
        (prefs.hideLandscape && prefs.isLandscape) || hiddenByApp

    /** 表示/非表示の状態を反映（隠すときはカレンダーも閉じる） */
    private fun updateVisibility() {
        val tv = label ?: return
        val hide = shouldHide()
        val v = if (hide) View.GONE else View.VISIBLE
        if (tv.visibility != v) {
            tv.visibility = v
            if (hide) hideCalendar() else tv.post { clampPosition(save = false) }
        }
    }

    private fun placeDefault() {
        val p = lp ?: return
        val dm = resources.displayMetrics
        p.x = (dm.widthPixels * 0.05f).toInt()
        p.y = (dm.heightPixels * 0.02f).toInt()
        clampPosition(save = false)
    }

    private fun movePreset(preset: Int) {
        val tv = label ?: return
        val p = lp ?: return
        val dm = resources.displayMetrics
        val margin = dp(8)
        p.x = when (preset) {
            PRESET_CENTER -> (dm.widthPixels - tv.width) / 2
            PRESET_RIGHT -> dm.widthPixels - tv.width - margin
            else -> margin
        }
        p.y = margin
        clampPosition(save = true)
    }

    private fun applyAppearance() {
        val tv = label ?: return
        val p = lp
        OverlayStyle.apply(this, tv, prefs)
        updateVisibility()
        if (p != null) {
            p.flags = baseFlags()
            try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
        }
        // 文字数が変わると幅も変わるので補正
        tv.post { clampPosition(save = false) }
    }

    private fun refreshText() {
        val tv = label ?: return
        // 夜間の減光は時刻の境目で切り替わるので、毎回濃さを合わせる
        val a = OverlayStyle.effectiveAlpha(prefs)
        if (tv.alpha != a) tv.alpha = a
        val pal = OverlayStyle.palette(this, prefs)
        val text = DateFormatJp.build(prefs, pal.darkBg)
        if (tv.text?.toString() != text.toString()) {
            tv.text = text
            tv.post { clampPosition(save = false) }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val chId = "jpdate_overlay"
        if (nm.getNotificationChannel(chId) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    chId,
                    getString(R.string.notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                ).apply { setShowBadge(false) }
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, DateOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, chId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(open)
            .addAction(0, "停止", stop)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        const val NOTIF_ID = 42
        const val ACTION_STOP = "jk.jpdate.STOP"
        const val ACTION_REFRESH = "jk.jpdate.REFRESH"
        const val ACTION_RESET_POS = "jk.jpdate.RESET_POS"
        const val EXTRA_PRESET = "preset"
        const val PRESET_LEFT = 0
        const val PRESET_CENTER = 1
        const val PRESET_RIGHT = 2

        fun start(ctx: Context) {
            val i = Intent(ctx, DateOverlayService::class.java)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_STOP)
            ctx.startService(i)
        }

        fun refresh(ctx: Context) {
            if (!Prefs(ctx).enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_REFRESH)
            ctx.startService(i)
        }

        fun resetPosition(ctx: Context) {
            val p = Prefs(ctx)
            p.resetPosition()
            if (!p.enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).setAction(ACTION_RESET_POS)
            ctx.startService(i)
        }

        fun movePreset(ctx: Context, preset: Int) {
            if (!Prefs(ctx).enabled) return
            val i = Intent(ctx, DateOverlayService::class.java).putExtra(EXTRA_PRESET, preset)
            ctx.startService(i)
        }
    }
}
