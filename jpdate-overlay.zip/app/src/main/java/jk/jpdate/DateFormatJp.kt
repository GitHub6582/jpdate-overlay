package jk.jpdate

import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.Locale

/** 日本語の年月日文字列を作る（端末のロケールに依存しない） */
object DateFormatJp {
    private val WEEKDAYS = arrayOf("月", "火", "水", "木", "金", "土", "日") // DayOfWeek.value 1..7

    /** 和暦の年（例: 令和8年 / 令和元年） */
    fun eraYear(date: LocalDate): String {
        val name: String
        val n: Int
        when {
            !date.isBefore(LocalDate.of(2019, 5, 1)) -> { name = "令和"; n = date.year - 2018 }
            !date.isBefore(LocalDate.of(1989, 1, 8)) -> { name = "平成"; n = date.year - 1988 }
            !date.isBefore(LocalDate.of(1926, 12, 25)) -> { name = "昭和"; n = date.year - 1925 }
            else -> return "${date.year}年"
        }
        return name + (if (n == 1) "元" else n.toString()) + "年"
    }

    /**
     * 表示文字列を作る。
     * @param darkBg 背景が暗いテーマか（土日祝の色を明るめ/濃いめで切り替える）
     */
    fun build(p: Prefs, darkBg: Boolean, now: LocalDateTime = LocalDateTime.now()): CharSequence {
        val date = now.toLocalDate()
        val sb = SpannableStringBuilder()

        when (p.yearMode) {
            1 -> sb.append("${date.year}年")
            2 -> sb.append(eraYear(date))
            3 -> sb.append("${date.year}年(${eraYear(date)})")
        }
        sb.append("${date.monthValue}月${date.dayOfMonth}日")

        val holiday = JpHoliday.name(date)
        val dow = date.dayOfWeek.value
        val red = if (darkBg) 0xFFFF8A80.toInt() else 0xFFD32F2F.toInt()
        val blue = if (darkBg) 0xFF82B1FF.toInt() else 0xFF1565C0.toInt()
        val dayColor = when {
            holiday != null || dow == 7 -> red
            dow == 6 -> blue
            else -> null
        }

        if (p.showWeekday) {
            val s = sb.length
            sb.append("(${WEEKDAYS[dow - 1]})")
            if (p.weekdayColor && dayColor != null) {
                sb.setSpan(ForegroundColorSpan(dayColor), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        if (p.showHoliday && holiday != null) {
            sb.append(" ")
            val s = sb.length
            sb.append(holiday)
            if (p.weekdayColor) {
                sb.setSpan(ForegroundColorSpan(red), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        if (p.timeMode > 0) {
            sb.append(if (p.twoLines) "\n" else "  ")
            sb.append(
                if (p.timeMode == 2) {
                    String.format(Locale.JAPAN, "%02d:%02d:%02d", now.hour, now.minute, now.second)
                } else {
                    String.format(Locale.JAPAN, "%02d:%02d", now.hour, now.minute)
                }
            )
        }

        if (p.showNextHoliday) {
            val nh = nextHoliday(date)
            if (nh != null) {
                sb.append("\n")
                val s = sb.length
                sb.append("あと${nh.first}日: ${nh.second}")
                sb.setSpan(RelativeSizeSpan(0.75f), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sb
    }

    private var cacheDate: LocalDate? = null
    private var cacheNext: Pair<Int, String>? = null

    /** 明日以降で最初の祝日までの (日数, 名前)。400日先まで探す。日付ごとにキャッシュ */
    fun nextHoliday(date: LocalDate): Pair<Int, String>? {
        if (date == cacheDate) return cacheNext
        var r: Pair<Int, String>? = null
        for (i in 1..400) {
            val n = JpHoliday.name(date.plusDays(i.toLong()))
            if (n != null) { r = Pair(i, n); break }
        }
        cacheDate = date
        cacheNext = r
        return r
    }
}
