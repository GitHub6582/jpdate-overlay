package jk.jpdate

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.YearMonth

/**
 * タップで出すミニカレンダー（月送り付き）。
 * 祝日=赤、日=赤、土=青、今日=緑の丸。本体タップで閉じる。
 */
class MiniCalendarView(
    ctx: Context,
    prefs: Prefs,
    private val onInteract: () -> Unit, // 操作されたので自動で閉じるタイマーを延長
    private val onResize: () -> Unit,   // 月を変えて大きさが変わったので位置を再計算
    private val onClose: () -> Unit     // 本体をタップした
) : LinearLayout(ctx) {

    private val pal = OverlayStyle.palette(ctx, prefs)
    private val red = if (pal.darkBg) 0xFFFF8A80.toInt() else 0xFFD32F2F.toInt()
    private val blue = if (pal.darkBg) 0xFF82B1FF.toInt() else 0xFF1565C0.toInt()
    private val density = ctx.resources.displayMetrics.density

    init {
        orientation = VERTICAL
        setPadding(dp(10), dp(8), dp(10), dp(10))
        background = GradientDrawable().apply {
            setColor(Color.argb(240, Color.red(pal.bg), Color.green(pal.bg), Color.blue(pal.bg)))
            cornerRadius = 12 * density
        }
        setOnClickListener { onClose() }
    }

    fun show(ym: YearMonth) {
        removeAllViews()

        // ---- ヘッダー（◀ 2026年10月 ▶）----
        val head = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(navButton("◀") { show(ym.minusMonths(1)); onInteract() })
        head.addView(
            TextView(context).apply {
                text = "${ym.year}年${ym.monthValue}月"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(pal.text)
                gravity = Gravity.CENTER
                setOnClickListener { show(YearMonth.now()); onInteract() }
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(navButton("▶") { show(ym.plusMonths(1)); onInteract() })
        addView(head)

        // ---- 曜日行 ----
        val wk = LinearLayout(context).apply { orientation = HORIZONTAL }
        val names = arrayOf("日", "月", "火", "水", "木", "金", "土")
        names.forEachIndexed { i, n ->
            val c = when (i) { 0 -> red; 6 -> blue; else -> pal.text }
            wk.addView(cell(n, c, false, 12f))
        }
        addView(wk)

        // ---- 日付 ----
        val offset = ym.atDay(1).dayOfWeek.value % 7 // 日曜=0
        val len = ym.lengthOfMonth()
        val today = LocalDate.now()
        val holidays = ArrayList<String>()
        var day = 1 - offset
        while (day <= len) {
            val row = LinearLayout(context).apply { orientation = HORIZONTAL }
            for (col in 0 until 7) {
                if (day in 1..len) {
                    val date = ym.atDay(day)
                    val h = JpHoliday.name(date)
                    if (h != null) holidays.add("${day}日 $h")
                    val c = when {
                        h != null || col == 0 -> red
                        col == 6 -> blue
                        else -> pal.text
                    }
                    row.addView(cell(day.toString(), c, date == today, 13f))
                } else {
                    row.addView(cell("", pal.text, false, 13f))
                }
                day++
            }
            addView(row)
        }

        // ---- 祝日一覧 ----
        if (holidays.isNotEmpty()) {
            addView(TextView(context).apply {
                text = holidays.joinToString("   ")
                textSize = 11f
                setTextColor(red)
                maxWidth = dp(CELL_W * 7)
                setPadding(0, dp(6), 0, 0)
            })
        }

        onResize()
    }

    private fun navButton(label: String, action: () -> Unit): TextView =
        TextView(context).apply {
            text = label
            textSize = 16f
            setTextColor(pal.text)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { action() }
        }

    private fun cell(s: String, color: Int, isToday: Boolean, sp: Float): TextView =
        TextView(context).apply {
            text = s
            textSize = sp
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(CELL_W), dp(CELL_H))
            if (isToday) {
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF2E7D32.toInt())
                }
            } else {
                setTextColor(color)
            }
        }

    private fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    companion object {
        private const val CELL_W = 36
        private const val CELL_H = 32
    }
}
