package jk.jpdate

import android.content.Context
import android.content.SharedPreferences

/** 表示位置・見た目の保存 */
class Prefs(private val ctx: Context) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences("jpdate", Context.MODE_PRIVATE)

    /** オーバーレイが有効か */
    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    /** 現在の画面が横向きか（表示領域の縦横で判定） */
    val isLandscape: Boolean
        get() {
            val dm = ctx.resources.displayMetrics
            return dm.widthPixels > dm.heightPixels
        }

    /** 画面上の X 座標（px）。縦向き・横向きで別々に保存。未設定は -1 */
    var x: Int
        get() = sp.getInt(if (isLandscape) "x_land" else "x", -1)
        set(v) = sp.edit().putInt(if (isLandscape) "x_land" else "x", v).apply()

    /** 画面上の Y 座標（px）。縦向き・横向きで別々に保存。未設定は -1 */
    var y: Int
        get() = sp.getInt(if (isLandscape) "y_land" else "y", -1)
        set(v) = sp.edit().putInt(if (isLandscape) "y_land" else "y", v).apply()

    /** 位置を未設定に戻す（縦横どちらも） */
    fun resetPosition() {
        sp.edit().remove("x").remove("y").remove("x_land").remove("y_land").apply()
    }

    /** 次の祝日までの日数を出すか */
    var showNextHoliday: Boolean
        get() = sp.getBoolean("show_next_holiday", false)
        set(v) = sp.edit().putBoolean("show_next_holiday", v).apply()

    /** 横向きのときは表示を隠すか（動画・ゲーム向け） */
    var hideLandscape: Boolean
        get() = sp.getBoolean("hide_landscape", false)
        set(v) = sp.edit().putBoolean("hide_landscape", v).apply()

    /** 文字サイズ（sp） */
    var textSp: Float
        get() = sp.getFloat("text_sp", 16f)
        set(v) = sp.edit().putFloat("text_sp", v.coerceIn(10f, 40f)).apply()

    /** 全体の不透明度 0.3〜1.0（v1.1 から別キー。既定は見やすいよう 100%） */
    var alpha: Float
        get() = sp.getFloat("alpha2", 1.0f)
        set(v) = sp.edit().putFloat("alpha2", v.coerceIn(0.3f, 1f)).apply()

    /** 背景の濃さ 0〜0.95（v1.1 から別キー。既定は見やすいよう 70%） */
    var bgAlpha: Float
        get() = sp.getFloat("bg_alpha2", 0.70f)
        set(v) = sp.edit().putFloat("bg_alpha2", v.coerceIn(0f, 0.95f)).apply()

    /** テーマ（THEME_*） */
    var theme: Int
        get() = sp.getInt("theme", THEME_DARK)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** 年の表示: 0=なし 1=西暦 2=和暦 3=西暦(和暦) */
    var yearMode: Int
        get() = sp.getInt("year_mode", if (sp.getBoolean("show_year", true)) 1 else 0)
        set(v) = sp.edit().putInt("year_mode", v).apply()

    /** 曜日を出すか */
    var showWeekday: Boolean
        get() = sp.getBoolean("show_weekday", true)
        set(v) = sp.edit().putBoolean("show_weekday", v).apply()

    /** 祝日名を出すか */
    var showHoliday: Boolean
        get() = sp.getBoolean("show_holiday", true)
        set(v) = sp.edit().putBoolean("show_holiday", v).apply()

    /** 土=青・日祝=赤で色分けするか */
    var weekdayColor: Boolean
        get() = sp.getBoolean("weekday_color", true)
        set(v) = sp.edit().putBoolean("weekday_color", v).apply()

    /** 時刻: 0=なし 1=時:分 2=時:分:秒 */
    var timeMode: Int
        get() = sp.getInt("time_mode", 0)
        set(v) = sp.edit().putInt("time_mode", v).apply()

    /** 日付と時刻を2行に分けるか */
    var twoLines: Boolean
        get() = sp.getBoolean("two_lines", false)
        set(v) = sp.edit().putBoolean("two_lines", v).apply()

    /** タッチを素通りさせる（ロック）。ONだとドラッグ不可、下のアプリを普通に操作できる */
    var lockPos: Boolean
        get() = sp.getBoolean("lock_pos", false)
        set(v) = sp.edit().putBoolean("lock_pos", v).apply()

    /** 起動時（再起動後）に自動で出すか */
    var autoStart: Boolean
        get() = sp.getBoolean("auto_start", true)
        set(v) = sp.edit().putBoolean("auto_start", v).apply()

    companion object {
        const val THEME_DARK = 0
        const val THEME_LIGHT = 1
        const val THEME_ZUNDA = 2
        const val THEME_YELLOW = 3
        const val THEME_AUTO = 4
    }
}
