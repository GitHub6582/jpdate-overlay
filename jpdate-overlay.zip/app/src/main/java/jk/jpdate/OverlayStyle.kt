package jk.jpdate

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView
import java.time.LocalTime

/** オーバーレイと設定画面プレビューで共通の見た目設定 */
object OverlayStyle {

    class Palette(val text: Int, val bg: Int, val darkBg: Boolean)

    private val DARK = Palette(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), true)
    private val LIGHT = Palette(0xFF111111.toInt(), 0xFFFFFFFF.toInt(), false)
    private val ZUNDA = Palette(0xFFFFFFFF.toInt(), 0xFF1E6B4F.toInt(), true)
    private val YELLOW = Palette(0xFFFFEB3B.toInt(), 0xFF000000.toInt(), true)

    fun palette(ctx: Context, prefs: Prefs): Palette = when (prefs.theme) {
        Prefs.THEME_LIGHT -> LIGHT
        Prefs.THEME_ZUNDA -> ZUNDA
        Prefs.THEME_YELLOW -> YELLOW
        Prefs.THEME_AUTO -> {
            val night = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
            if (night == Configuration.UI_MODE_NIGHT_YES) DARK else LIGHT
        }
        else -> DARK
    }

    /** いま夜間の減光時間帯か（日をまたぐ範囲に対応） */
    fun isDimNow(prefs: Prefs, now: LocalTime = LocalTime.now()): Boolean {
        if (!prefs.dimEnabled) return false
        val s = prefs.dimStart
        val e = prefs.dimEnd
        if (s == e) return false
        val m = now.hour * 60 + now.minute
        return if (s < e) m in s until e else (m >= s || m < e)
    }

    /** 減光中なら dimLevel、そうでなければ 1 */
    fun dimFactor(prefs: Prefs): Float = if (isDimNow(prefs)) prefs.dimLevel else 1f

    /** 全体の濃さ × 減光 */
    fun effectiveAlpha(prefs: Prefs): Float = prefs.alpha * dimFactor(prefs)

    /** TextView に色・サイズ・背景・テキストをまとめて適用する（dim=false で減光を無視。設定画面のプレビュー用） */
    fun apply(ctx: Context, tv: TextView, prefs: Prefs, dim: Boolean = true) {
        val pal = palette(ctx, prefs)
        val d = ctx.resources.displayMetrics.density
        tv.setTextColor(pal.text)
        tv.textSize = prefs.textSp
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.alpha = if (dim) effectiveAlpha(prefs) else prefs.alpha
        // 背景が薄いときの保険として、文字色と反対色の縁取り風シャドウ
        tv.setShadowLayer(
            if (prefs.bgAlpha < 0.35f) 4f else 0f, 0f, 0f,
            if (pal.darkBg) Color.BLACK else Color.WHITE
        )
        val a = (prefs.bgAlpha * 255).toInt().coerceIn(0, 255)
        tv.background = GradientDrawable().apply {
            setColor(Color.argb(a, Color.red(pal.bg), Color.green(pal.bg), Color.blue(pal.bg)))
            cornerRadius = 8 * d
        }
        tv.text = DateFormatJp.build(prefs, pal.darkBg)
    }
}
