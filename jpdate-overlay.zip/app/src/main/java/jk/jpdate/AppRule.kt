package jk.jpdate

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Process

/** 「特定のアプリを前面にしたときだけ隠す/表示する」のための補助 */
object AppRule {

    class AppItem(val pkg: String, val label: String)

    /** 使用状況へのアクセスが許可されているか（前面アプリの検出に必要） */
    fun hasUsageAccess(ctx: Context): Boolean {
        val ao = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ao.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** ランチャーに出るアプリ一覧（自分自身は除く、名前順） */
    fun launchableApps(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val list = pm.queryIntentActivities(i, 0)
        return list
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}
