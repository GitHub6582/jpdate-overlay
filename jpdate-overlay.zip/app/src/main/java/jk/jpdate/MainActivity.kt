package jk.jpdate

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * 設定画面（スクロール対応）。
 * - 白背景/黒背景の上でのプレビュー
 * - オーバーレイ権限・表示ON/OFF
 * - テーマ・年/和暦・曜日・祝日・時刻・色分け
 * - 文字サイズ・不透明度・背景の濃さ
 * - 位置プリセット・ロック・起動時自動開始
 */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var enableSwitch: Switch
    private lateinit var previewLight: TextView
    private lateinit var previewDark: TextView
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val previewTick = object : Runnable {
        override fun run() {
            updatePreview()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF121212.toInt())
            isFillViewport = true
            addView(root)
        }

        root.addView(text("日本語日付", 22f, 0xFFFFFFFF.toInt()).apply {
            setPadding(0, 0, 0, dp(4))
        })
        root.addView(text(
            "画面の好きな位置に、日本語の年月日を常時表示します。\n" +
                "表示中の日付はドラッグで移動、長押しでこの画面を開けます。",
            13f, 0xFFB0B0B0.toInt()
        ).apply { setPadding(0, 0, 0, dp(12)) })

        // ---- プレビュー（白背景・黒背景の両方で見え方を確認）----
        root.addView(section("プレビュー（白い画面 / 黒い画面）"))
        val previewRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        previewLight = TextView(this).apply { setPadding(dp(12), dp(6), dp(12), dp(6)) }
        previewDark = TextView(this).apply { setPadding(dp(12), dp(6), dp(12), dp(6)) }
        previewRow.addView(previewBox(0xFFFFFFFF.toInt(), previewLight), weightParams())
        previewRow.addView(previewBox(0xFF000000.toInt(), previewDark), weightParams())
        root.addView(previewRow)

        status = text("", 13f, 0xFFE0E0E0.toInt()).apply { setPadding(0, dp(12), 0, dp(8)) }
        root.addView(status)

        // ---- 権限 ----
        root.addView(Button(this).apply {
            text = "他のアプリの上に表示する許可"
            setOnClickListener { openOverlaySettings() }
        })
        if (Build.VERSION.SDK_INT >= 33) {
            root.addView(Button(this).apply {
                text = "通知の許可（常駐に必要）"
                setOnClickListener {
                    ActivityCompat.requestPermissions(
                        this@MainActivity,
                        arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                        1
                    )
                }
            })
        }

        // ---- ON/OFF ----
        enableSwitch = toggle("日付を表示する", prefs.enabled) { on ->
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    enableSwitch.isChecked = false
                    Toast.makeText(this, "先に「他のアプリの上に表示」を許可してください", Toast.LENGTH_LONG).show()
                    openOverlaySettings()
                } else {
                    prefs.enabled = true
                    DateOverlayService.start(this)
                }
            } else {
                prefs.enabled = false
                DateOverlayService.stop(this)
            }
            refreshStatus()
        }
        root.addView(enableSwitch)

        root.addView(toggle("端末の起動後に自動で表示", prefs.autoStart) { prefs.autoStart = it })

        // ---- 見た目 ----
        root.addView(section("テーマ（見づらいときはここ）"))
        root.addView(chips(
            listOf("ダーク", "ライト", "ずんだ", "黄色", "自動"),
            prefs.theme
        ) { prefs.theme = it; changed() })
        root.addView(hint("自動 = 端末のダーク/ライト設定に合わせて切り替え"))

        root.addView(section("年の表示"))
        root.addView(chips(listOf("なし", "西暦", "和暦", "両方"), prefs.yearMode) {
            prefs.yearMode = it; changed()
        })

        root.addView(section("時刻"))
        root.addView(chips(listOf("なし", "時:分", "時:分:秒"), prefs.timeMode) {
            prefs.timeMode = it; changed()
        })
        root.addView(toggle("日付と時刻を2行に分ける", prefs.twoLines) { prefs.twoLines = it; changed() })

        root.addView(section("日付の内容"))
        root.addView(toggle("曜日を表示（水）", prefs.showWeekday) { prefs.showWeekday = it; changed() })
        root.addView(toggle("祝日名を表示（文化の日 など）", prefs.showHoliday) { prefs.showHoliday = it; changed() })
        root.addView(toggle("土曜=青・日祝=赤で色分け", prefs.weekdayColor) { prefs.weekdayColor = it; changed() })

        // ---- スライダー ----
        root.addView(section("大きさ・濃さ"))
        addSlider(root, "文字サイズ", 10, 40, prefs.textSp.toInt(), { "${it}sp" }) {
            prefs.textSp = it.toFloat(); changed()
        }
        addSlider(root, "全体の濃さ", 30, 100, (prefs.alpha * 100).toInt(), { "${it}%" }) {
            prefs.alpha = it / 100f; changed()
        }
        addSlider(root, "背景の濃さ", 0, 95, (prefs.bgAlpha * 100).toInt(), { "${it}%" }) {
            prefs.bgAlpha = it / 100f; changed()
        }

        // ---- 位置 ----
        root.addView(section("位置"))
        root.addView(chips(listOf("左上", "中央上", "右上", "初期位置"), -1) { i ->
            when (i) {
                0 -> DateOverlayService.movePreset(this, DateOverlayService.PRESET_LEFT)
                1 -> DateOverlayService.movePreset(this, DateOverlayService.PRESET_CENTER)
                2 -> DateOverlayService.movePreset(this, DateOverlayService.PRESET_RIGHT)
                else -> DateOverlayService.resetPosition(this)
            }
        }.also { /* 押しっぱなしの選択表示はしない */ })
        root.addView(toggle("位置をロック（タッチを素通り）", prefs.lockPos) { prefs.lockPos = it; changed() })
        root.addView(hint("ロック中は日付の下のアプリを普通に操作できます。動かしたいときはOFFに。"))

        root.addView(section("クイック設定"))
        root.addView(hint("通知パネルを下に引き、鉛筆(編集)から「日本語日付」タイルを追加すると、ワンタップでON/OFFできます。"))

        root.addView(text(versionText(), 12f, 0xFF888888.toInt()).apply {
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(scroll)
        maybeRequestNotif()
        updatePreview()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        enableSwitch.isChecked = prefs.enabled && Settings.canDrawOverlays(this)
        handler.post(previewTick)
        refreshStatus()
    }

    override fun onPause() {
        handler.removeCallbacks(previewTick)
        super.onPause()
    }

    // ---------- 部品 ----------

    private fun changed() {
        updatePreview()
        DateOverlayService.refresh(this)
        refreshStatus()
    }

    private fun updatePreview() {
        OverlayStyle.apply(this, previewLight, prefs)
        OverlayStyle.apply(this, previewDark, prefs)
    }

    private fun previewBox(bg: Int, tv: TextView): FrameLayout =
        FrameLayout(this).apply {
            setBackgroundColor(bg)
            setPadding(dp(8), dp(14), dp(8), dp(14))
            addView(tv, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
        }

    private fun weightParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(2), 0, dp(2), 0)
        }

    private fun text(s: String, sp: Float, color: Int): TextView =
        TextView(this).apply {
            text = s
            textSize = sp
            setTextColor(color)
        }

    private fun section(s: String): TextView =
        text(s, 14f, 0xFF81C784.toInt()).apply { setPadding(0, dp(20), 0, dp(6)) }

    private fun hint(s: String): TextView =
        text(s, 12f, 0xFF888888.toInt()).apply { setPadding(0, dp(4), 0, 0) }

    private fun toggle(label: String, initial: Boolean, onChange: (Boolean) -> Unit): Switch =
        Switch(this).apply {
            text = label
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = initial
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }

    /** 横並びの選択チップ。current=-1 のときは選択状態を持たないボタン列として動く */
    private fun chips(labels: List<String>, current: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val views = ArrayList<TextView>()
        var selected = current
        fun paint() {
            views.forEachIndexed { i, v ->
                val on = i == selected
                v.setBackgroundColor(if (on) 0xFF2E7D32.toInt() else 0xFF2A2A2A.toInt())
                v.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFFCCCCCC.toInt())
            }
        }
        labels.forEachIndexed { i, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener {
                    if (current >= 0) selected = i
                    paint()
                    onSelect(i)
                }
            }
            views.add(v)
            row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        paint()
        return row
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        min: Int,
        max: Int,
        initial: Int,
        fmt: (Int) -> String,
        onValue: (Int) -> Unit
    ) {
        val label = text("$title: ${fmt(initial)}", 13f, 0xFFCCCCCC.toInt()).apply {
            setPadding(0, dp(8), 0, 0)
        }
        parent.addView(label)
        parent.addView(SeekBar(this).apply {
            this.max = max - min
            progress = (initial - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = min + p
                    label.text = "$title: ${fmt(v)}"
                    if (fromUser) onValue(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun versionText(): String {
        return try {
            @Suppress("DEPRECATION")
            val pi = packageManager.getPackageInfo(packageName, 0)
            @Suppress("DEPRECATION")
            "バージョン ${pi.versionName} (build ${pi.versionCode})"
        } catch (_: Exception) {
            "バージョン不明"
        }
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val running = prefs.enabled && overlay
        status.text = buildString {
            append(if (overlay) "✓ オーバーレイ許可: OK" else "✗ オーバーレイ許可: 未許可")
            append("\n")
            append(if (running) "✓ 表示中" else "— 非表示")
        }
    }

    private fun openOverlaySettings() {
        val i = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(i)
    }

    private fun maybeRequestNotif() {
        if (Build.VERSION.SDK_INT >= 33) {
            val ok = ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!ok) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    1
                )
            }
        }
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()
}
