package jk.jpdate

import java.time.DayOfWeek
import java.time.LocalDate

/**
 * 日本の祝日判定（2000年以降）。
 * 春分・秋分は 1980〜2099 年用の近似式。振替休日・国民の休日・2020/2021 の特例移動に対応。
 */
object JpHoliday {

    /** その日が祝日・振替休日・国民の休日ならその名前、そうでなければ null */
    fun name(date: LocalDate): String? {
        if (date.year < 2000) return null
        base(date)?.let { return it }

        // 振替休日: 直前の「連続する祝日」の頭が日曜なら、最初の平日（祝日でない日）が振替
        if (date.year >= 2007) {
            var prev = date.minusDays(1)
            while (base(prev) != null) {
                if (prev.dayOfWeek == DayOfWeek.SUNDAY) return "振替休日"
                prev = prev.minusDays(1)
            }
        }

        // 国民の休日: 前後が祝日に挟まれた平日
        if (date.dayOfWeek != DayOfWeek.SUNDAY &&
            base(date.minusDays(1)) != null &&
            base(date.plusDays(1)) != null
        ) {
            return "国民の休日"
        }
        return null
    }

    private fun nthMonday(d: LocalDate, n: Int): Boolean =
        d.dayOfWeek == DayOfWeek.MONDAY && (d.dayOfMonth - 1) / 7 + 1 == n

    private fun base(date: LocalDate): String? {
        val y = date.year
        val m = date.monthValue
        val d = date.dayOfMonth
        return when (m) {
            1 -> when {
                d == 1 -> "元日"
                nthMonday(date, 2) -> "成人の日"
                else -> null
            }
            2 -> when {
                d == 11 -> "建国記念の日"
                d == 23 && y >= 2020 -> "天皇誕生日"
                else -> null
            }
            3 -> if (d == springEquinox(y)) "春分の日" else null
            4 -> if (d == 29) (if (y >= 2007) "昭和の日" else "みどりの日") else null
            5 -> when {
                d == 3 -> "憲法記念日"
                d == 4 && y >= 2007 -> "みどりの日"
                d == 5 -> "こどもの日"
                else -> null
            }
            7 -> when {
                y == 2020 && d == 23 -> "海の日"
                y == 2021 && d == 22 -> "海の日"
                y == 2020 && d == 24 -> "スポーツの日"
                y == 2021 && d == 23 -> "スポーツの日"
                y != 2020 && y != 2021 && nthMonday(date, 3) -> "海の日"
                else -> null
            }
            8 -> when {
                y == 2020 -> if (d == 10) "山の日" else null
                y == 2021 -> if (d == 8) "山の日" else null
                d == 11 -> "山の日"
                else -> null
            }
            9 -> when {
                d == autumnEquinox(y) -> "秋分の日"
                nthMonday(date, 3) -> "敬老の日"
                else -> null
            }
            10 -> when {
                y == 2020 || y == 2021 -> null
                nthMonday(date, 2) -> if (y >= 2020) "スポーツの日" else "体育の日"
                else -> null
            }
            11 -> when (d) {
                3 -> "文化の日"
                23 -> "勤労感謝の日"
                else -> null
            }
            12 -> if (d == 23 && y in 1989..2018) "天皇誕生日" else null
            else -> null
        }
    }

    private fun springEquinox(y: Int): Int =
        (20.8431 + 0.242194 * (y - 1980) - (y - 1980) / 4).toInt()

    private fun autumnEquinox(y: Int): Int =
        (23.2488 + 0.242194 * (y - 1980) - (y - 1980) / 4).toInt()
}
