package jk.jpdate

import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** クイック設定のタイル: ワンタップでオーバーレイ表示をON/OFF */
class DateTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        val prefs = Prefs(this)
        if (prefs.enabled) {
            prefs.enabled = false
            DateOverlayService.stop(this)
        } else if (!Settings.canDrawOverlays(this)) {
            openApp()
            return
        } else {
            try {
                prefs.enabled = true
                DateOverlayService.start(this)
            } catch (_: Exception) {
                prefs.enabled = false
                openApp()
                return
            }
        }
        update()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        @Suppress("DEPRECATION")
        startActivityAndCollapse(i)
    }

    private fun update() {
        val t = qsTile ?: return
        t.state = if (Prefs(this).enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = getString(R.string.tile_label)
        t.updateTile()
    }
}
